afficher une chaine de caractere sur allegro : 
https://stackoverflow.com/questions/17255274/allegro-5-al-draw-textf

effacer un caractere d'une chaine:
https://www.cplusplus.com/reference/string/string/erase/

# cluedo
