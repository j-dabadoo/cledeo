#include "header.h"


/// ////////////////////////////////// ///
/// PERMET DE PASSER AU JOUEUR SUIVANT ///
/// ////////////////////////////////// ///

void tourParTour(int& tour, int& nb_joueurs)
{
    while(key[KEY_SPACE])
    {}

    tour++ ; ///Incrementation du compteur tour pour passer au joueur suivant

    ///Revient au premier joueur
    if (tour==nb_joueurs)
        tour=0 ;
}



/// /////////////////// ///
/// LANCEMENT DES 2 D�S ///
/// /////////////////// ///

int lancerDe()
{
    return rand()%(11)+2; ///G�n�ration d'un nombre al�atoire entre 2 et 12
}




/// //////////////////////////// ///
/// ACTUALISATION DE L'AFFICHAGE ///
/// //////////////////////////// ///

void actualisation(BITMAP* buffer, BITMAP* plateau, std::vector<Joueur>& joueurs, int& tour)
{
    blit(plateau, buffer, 0,0,0,0, SCREEN_W, SCREEN_H);

    ///Affichage des pions
    for(const auto& joueur:joueurs)
        draw_sprite(buffer, joueur.getImagePion(), joueur.getPosX()*23.25, joueur.getPosY()*23.5) ;

    //al_draw_text(font,makecol(255,255,255), 700,50, 0, "%s", joueurs[tour].getNom());
    textprintf_ex(buffer, font, 700, 50, makecol(255,255,255), -1, "%s", joueurs[tour].getNom().c_str());
    ///Affichage des cartes du joueurs
    joueurs[tour].cardDisplay(buffer);

    ///Affichage du buffer � l'�cran
    blit(buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
}




