#include "Hypothese.h"

Hypothese::Hypothese()
{
    //ctor
}

Hypothese::~Hypothese()
{
    //dtor
}

/////////////////
//// GETTERS ////
/////////////////
std::string Hypothese::getLieu()
{
    return m_lieu;
}
std::string Hypothese::getArme()
{
    return m_arme;
}
std::string Hypothese::getPersonnage()
{
    return m_personnage;
}std::string Hypothese::getJou()
{
    return m_jou;
}
/////////////////
//// SETTERS ////
/////////////////

void Hypothese:: setLieu(std::string lieu)
{
    m_lieu=lieu;
}
void Hypothese:: setPersonnage(std::string personnage)
{
    m_personnage=personnage;
}
void Hypothese:: setArme(std::string arme)
{
    m_arme=arme;
}void Hypothese:: setJou(std::string jou)
{
    m_jou=jou;
}

/////////////////
//// AUTRES  ////
/////////////////

void Hypothese::displayHypo()
{
    textprintf_ex(screen,font, 500, 475,makecol(239, 228, 176), -1, getPersonnage().c_str());
    textprintf_ex(screen,font, 500, 510,makecol(239, 228, 176), -1, getLieu().c_str());
    textprintf_ex(screen,font, 500, 535,makecol(239, 228, 176), -1, getArme().c_str());
    textprintf_ex(screen,font, 500, 560,makecol(239, 228, 176), -1, getJou().c_str());

}
