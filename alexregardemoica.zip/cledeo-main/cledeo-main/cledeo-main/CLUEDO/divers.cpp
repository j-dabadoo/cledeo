#include "header.h"

/// ////////////////////////////////// ///
/// PERMET DE PASSER AU JOUEUR SUIVANT ///
/// ////////////////////////////////// ///

void tourParTour(int& tour, int& nb_joueurs)
{
    while(key[KEY_SPACE])
    {}

    tour++ ; ///Incrementation du compteur tour pour passer au joueur suivant

    ///Revient au premier joueur
    if (tour==nb_joueurs)
        tour=0 ;
}

/// /////////////////// ///
/// LANCEMENT DES 2 D�S ///
/// /////////////////// ///

int lancerDe()
{
    return rand()%(11)+2; ///G�n�ration d'un nombre al�atoire entre 2 et 12
}




/// //////////////////////////// ///
/// ACTUALISATION DE L'AFFICHAGE ///
/// //////////////////////////// ///

void actualisation(BITMAP* buffer, BITMAP* plateau, std::vector<Joueur>& joueurs, int& tour)
{
    int choixint;

    choixint=plateaudebase(buffer);

    //blit(plateau, buffer, 0,0,0,0, SCREEN_W, SCREEN_H);

    ///Affichage des pions
    //for(const auto& joueur:joueurs)
    //draw_sprite(buffer, joueur.getImagePion(), joueur.getPosX()*23.25, joueur.getPosY()*23.5) ;

    //al_draw_text(font,makecol(255,255,255), 700,50, 0, "%s", joueurs[tour].getNom());

    if(choixint==1)
    {
        while(!key[KEY_SPACE])
        {
            affichehypo(buffer, joueurs, tour);
            actionhypo(choixint, joueurs, tour);
        }
    }
    else
    {

        textprintf_ex(buffer, font, 700, 50, makecol(255,255,255), -1, "%s", joueurs[tour].getNom().c_str());
        ///Affichage des cartes du joueurs
        joueurs[tour].cardDisplay(buffer);
    }


    ///Affichage du buffer � l'�cran
    blit(buffer, screen, 0,0,0,0, SCREEN_W, SCREEN_H);
}

int plateaudebase(BITMAP* page)
{
    BITMAP* plateau;

    plateau=load_bitmap("images/plateau.bmp", NULL);
    blit(plateau, page, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

    ///quitter le jeu
    rectfill(page,620,125,820,175,makecol(127,127,127));
    ///bouton hypothese
    rectfill(page,620,225,820,275,makecol(208,82,41));
    ///zone de d�
    rectfill(page,900,75,1150,325,makecol(59,162,71));
    ///zone des joueurs
    rectfill(page,620,375,1150,550,makecol(136,0,21));

    show_mouse(page);
    if(mouse_x>=620 && mouse_x<=820 && mouse_y>=225 && mouse_y<=275)
    {
        rect(page, 617, 222, 823, 278, makecol(208,82,41));

    }
    else
        rect(page, 617, 222, 823, 278, makecol(0,0,0));

    if(mouse_b &1)
    {
        if(mouse_x>=620 && mouse_x<=820 && mouse_y>=225 && mouse_y<=275)
        {
            return 1;
        }

    }

    //blit(page, screen, 0,0,0,0,SCREEN_W,SCREEN_H);
}
void affichehypo(BITMAP* page, std::vector<Joueur>& joueurs, int& tour)
{
    clear_bitmap(page);

    ///BITMAP
    //personnages
    BITMAP* barbenoire;
    BITMAP* billturner;
    BITMAP* calypso;
    BITMAP* davyjones;
    BITMAP* jacksparrow;
    BITMAP* jamesnorrington;
    BITMAP* swann;
    BITMAP* barbossa;
    BITMAP* willturner;

    //armes
    BITMAP* canon;
    BITMAP* cle;
    BITMAP* pistolet;
    BITMAP* poudre;
    BITMAP* sabre;
    BITMAP* tirebouchon;

    ///telechargement des bitmap
    //personnages
    barbenoire=load_bitmap("images/barbenoire.bmp", NULL);
    billturner=load_bitmap("images/billturner.bmp", NULL);
    calypso=load_bitmap("images/calypso.bmp", NULL);
    davyjones=load_bitmap("images/davyjones.bmp", NULL);
    jacksparrow=load_bitmap("images/jacksparrow.bmp", NULL);
    jamesnorrington=load_bitmap("images/jamesnorrington.bmp", NULL);
    swann=load_bitmap("images/swann.bmp", NULL);
    barbossa=load_bitmap("images/barbossa.bmp", NULL);
    willturner=load_bitmap("images/willturner.bmp", NULL);

    //armes
    canon=load_bitmap("images/canon.bmp", NULL);
    pistolet=load_bitmap("images/pistolet.bmp", NULL);
    poudre=load_bitmap("images/poudre.bmp", NULL);
    sabre=load_bitmap("images/sabre.bmp", NULL);
    cle=load_bitmap("images/cle.bmp", NULL);
    tirebouchon=load_bitmap("images/tirebouchon.bmp", NULL);

    ///cadre de jade
    rectfill(page,0,0,400,600,makecol(239,228,176));
    for(int i=0; i<25; i++)
    {
        hline(page, 0, (25+ i*25), 400, makecol(0, 0, 0));
    }
    vline(page, 350, 0, 600, makecol(0, 0, 0));

    show_mouse(screen);
    ///affichage des personnages
    textprintf_ex(page,font, 500, 75,makecol(239, 228, 176), -1, "personnages: ");
    blit(barbenoire, page,0,0, 402, 85, SCREEN_W, SCREEN_H);
    blit(billturner, page,0,0, 490, 85, SCREEN_W, SCREEN_H);
    blit(calypso, page, 0,0,578, 85, SCREEN_W, SCREEN_H);
    blit(davyjones, page,0,0, 666, 85, SCREEN_W, SCREEN_H);
    blit(jacksparrow, page,0,0, 754, 85,SCREEN_W, SCREEN_H);
    blit(jamesnorrington, page,0,0, 842, 85, SCREEN_W, SCREEN_H);
    blit(swann, page,0,0, 930, 85, SCREEN_W, SCREEN_H);
    blit(barbossa, page, 0,0,1018, 85, SCREEN_W, SCREEN_H);
    blit(willturner, page,0,0, 1106, 85, SCREEN_W, SCREEN_H);

    textprintf_ex(page,font, 500, 275,makecol(239, 228, 176), -1, "armes: ");
    blit(canon, page,0,0, 402, 285, SCREEN_W, SCREEN_H);
    blit(poudre, page,0,0, 535, 285, SCREEN_W, SCREEN_H);
    blit(tirebouchon, page, 0,0,668, 285, SCREEN_W, SCREEN_H);
    blit(cle, page,0,0, 801, 285, SCREEN_W, SCREEN_H);
    blit(sabre, page,0,0, 934, 285,SCREEN_W, SCREEN_H);
    blit(pistolet, page,0,0, 1067, 285, SCREEN_W, SCREEN_H);


    int i=0;
    textprintf_ex(page,font, 500, 435,makecol(239, 228, 176), -1, "joueurs: ");


    for(const auto& elem: joueurs)
    {

        draw_sprite(page, elem.getImagePion(), 450+i, 450) ;
        i=i+100;
    }
    blit(page, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
}

void actionhypo(int choixint, std::vector<Joueur>& joueurs, int& tour)
{
    int valiarme=0, valiperso=0, valilieu=0, valijou=0, validefinal=0;
    Hypothese hypformulee;
    std::string hypoarme;
    std::string hypopersonnage;
    std::string hypojou;
    std::string hypolieu;

    ////// hypothese du personnage
    while(valiperso!=1)
    {
        if((mouse_b & 1)&&(mouse_x>=402 && mouse_x<=462 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Barbenoire";
            valiperso=1;
        }
        if((mouse_b & 1)&&(mouse_x>=490 && mouse_x<=550 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Bill Turner";
            valiperso=1;
        }
        if((mouse_b & 1)&&(mouse_x>=578 && mouse_x<=638 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Calypso";
            valiperso=1;
        }
        if((mouse_b & 1)&&(mouse_x>=666 && mouse_x<=726 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Davy Jones";
            valiperso=1;
        }
        if((mouse_b & 1)&&(mouse_x>=754 && mouse_x<=814 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Jack Sparrow";
            valiperso=1;

        }
        if((mouse_b & 1)&&(mouse_x>=842 && mouse_x<=902 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="James Norrington";
            valiperso=1;
        }
        if((mouse_b & 1)&& (mouse_x>=930 && mouse_x<=990 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Swann";
            valiperso=1;
        }
        if((mouse_b & 1)&&( mouse_x>=1078 && mouse_x<=1138 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Barbossa";
            valiperso=1;
        }
        if((mouse_b & 1)&&(mouse_x>=1106 && mouse_x<=1166 && mouse_y>=85 && mouse_y<=185))
        {
            hypopersonnage="Will Turner";
            valiperso=1;
        }

    }
    /////////////hypothese de l'arme
    while(valiarme!=1)
    {

        if(mouse_b&1 &&(mouse_x>=402 && mouse_x<=462 && mouse_y>=285 && mouse_y<=385))
        {
            hypoarme="Canon";
            valiarme=1;
        }
        if((mouse_b & 1)&&(mouse_x>=535 && mouse_x<=595 && mouse_y>=285 && mouse_y<=385))
        {
            hypoarme="Poudre";
            valiarme=1;
        }
        if((mouse_b & 1)&&(mouse_x>=668 && mouse_x<=728 && mouse_y>=285 && mouse_y<=385))
        {
            hypoarme="Tire Bouchon";
            valiarme=1;
        }
        if((mouse_b & 1)&&(mouse_x>=801 && mouse_x<=861 && mouse_y>=285 && mouse_y<=385))
        {
            hypoarme="Cle";
            valiarme=1;
        }
        if((mouse_b & 1)&&(mouse_x>=934 && mouse_x<=994 && mouse_y>=285 && mouse_y<=385))
        {
            hypoarme="Sabre";
            valiarme=1;
        }
        if((mouse_b & 1)&&(mouse_x>=1067 && mouse_x<=1127 && mouse_y>=285 && mouse_y<=385))
        {
            hypoarme="Pistolet";
            valiarme=1;
        }
    }
    int joueurchoisi=0, deplacement=0;
    while(valijou!=1)
    {
        for(int i=1; i<=tour; i++)
        {
            if(mouse_b &1 &&(mouse_x>=(450+deplacement) && mouse_x<=(473+deplacement) && mouse_y>=450 && mouse_y<=475))
            {
                joueurchoisi=i;
                if(joueurchoisi!=tour)
                {
                    hypojou=joueurs[joueurchoisi].getNom();
                }
                valijou=1;
                deplacement=deplacement+100;
            }
        }

    }

    hypolieu=trouvlieu(joueurs[tour]);
    valilieu=1;

    ///changement avec les setters
    hypformulee.setArme(hypoarme);
    hypformulee.setLieu(hypolieu);
    hypformulee.setPersonnage(hypopersonnage);

    if(valiarme==1 && valiperso==1 && valilieu==1 && valijou==1)
    {
        hypformulee.displayHypo();
        rest(10000);
        incluhypo(joueurs, tour, hypformulee);
    }
}
std::string trouvlieu(Joueur lejoueur)
{
    ///Si le joueur est dans :
    ///Le Hollandais Volant
    if(lejoueur.getPosX() < 7 && lejoueur.getPosY() < 7)
        return "Hollandais Volant";

    ///L'Ile des 4 vents
    else if(lejoueur.getPosX() > 10 && lejoueur.getPosX() < 17 && lejoueur.getPosY() < 8)
        return "Ile des 4 vents";

    ///Le Port Royal
    else if(lejoueur.getPosX() > 20 && lejoueur.getPosY() < 6)
        return "Port Royal";

    ///L'Ile de la Muerta
    else if(lejoueur.getPosX() < 9 && lejoueur.getPosY() > 9 && lejoueur.getPosY() < 16)
        return "Ile de la Muerta";

    ///Le Triangle des Bermudes
    else if(lejoueur.getPosX() > 11 && lejoueur.getPosY() > 8 && lejoueur.getPosY() < 13)
        return "Triangle des Bermudes";

    ///L'Ile au rhum
    else if(lejoueur.getPosX() > 18 && lejoueur.getPosY() > 14 && lejoueur.getPosY() < 19)
        return "Ile au rhum";

    ///Le Black Pearl
    else if(lejoueur.getPosX() < 8 && lejoueur.getPosY() > 19)
        return "Black Pearl";

    ///La Baie des Naufrag�s
    else if(lejoueur.getPosX() > 10 && lejoueur.getPosX() < 16 && lejoueur.getPosY() > 18)
        return "Baie des Naufrages";

    ///Le HMS Intrepide
    else if(lejoueur.getPosX() > 18 && lejoueur.getPosY() > 21)
        return "HMS Intrepide";

    ///L'Ile de Tortuga
    else if(lejoueur.getPosX() > 11 && lejoueur.getPosX() < 16 && lejoueur.getPosY() > 9 && lejoueur.getPosY() < 17)
        return "Tortuga";

    else return "Couloir";
}

void incluhypo(std::vector<Joueur>& joueurs, int& tour, Hypothese hypoaajt)
{
    joueurs[tour].setHypo(hypoaajt.getArme());
    joueurs[tour].setHypo(hypoaajt.getLieu());
    joueurs[tour].setHypo(hypoaajt.getPersonnage());
}
